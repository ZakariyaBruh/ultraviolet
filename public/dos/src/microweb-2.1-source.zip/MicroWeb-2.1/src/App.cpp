//
// Copyright (C) 2021 James Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//

#include <direct.h>
#include <stdio.h>
#include "App.h"
#include "Platform.h"
#include "HTTP.h"
#include "Image/Decoder.h"

App* App::app;
AppConfig App::config;

App::App() 
	: page(*this), pageRenderer(*this), parser(page), ui(*this)
{
	app = this;
	requestedNewPage = false;

	memset(pageHistoryBuffer, 0, MAX_PAGE_HISTORY_BUFFER_SIZE);
	pageHistoryPtr = pageHistoryBuffer;
}

App::~App()
{
	app = NULL;
}


void App::ResetPage()
{
	StylePool::Get().Reset();
	page.Reset();
	parser.Reset();
	pageRenderer.Reset();
	ui.Reset();
	pageRenderer.RefreshAll();
}

void App::Run(int argc, char* argv[])
{
	running = true;
	char* targetURL = nullptr;

	config.loadImages = true;
	config.dumpPage = false;
	config.useSwap = false;
	config.useEMS = true;
	config.useXMS = true;

	if (argc > 1)
	{
		for (int n = 1; n < argc; n++)
		{
			if (*argv[n] != '-')
			{
				targetURL = argv[n];
				break;
			}
			else if (!stricmp(argv[n], "-noimages"))
			{
				config.loadImages = false;
			}
			else if (!stricmp(argv[n], "-dumppage"))
			{
				config.dumpPage = true;
			}
			else if (!stricmp(argv[n], "-invert"))
			{
				config.invertScreen = true;
			}
			else if (!stricmp(argv[n], "-useswap"))
			{
				config.useSwap = true;
			}
			else if (!stricmp(argv[n], "-noems"))
			{
				config.useEMS = false;
			}
			else if (!stricmp(argv[n], "-noxms"))
			{
				config.useXMS = false;
			}
		}
	}

	MemoryManager::pageBlockAllocator.Init();

	if (config.loadImages)
	{
		ImageDecoder::Allocate();
	}

	StylePool::Get().Init();
	ui.Init();
	page.Reset();
	pageRenderer.Init();

	if (targetURL)
	{
		OpenURL(HTTPRequest::Get, targetURL);
	}
	else
	{
		ui.FocusNode(ui.addressBarNode);
	}

	while (running)
	{
		Platform::Update();

		if (pageLoadTask.HasContent())
		{
			if (requestedNewPage)
			{
				if (pageLoadTask.downloadFile)
				{
					ui.SetStatusMessage("Downloading content...", StatusBarNode::GeneralStatus);
				}
				else
				{
					ResetPage();
					page.pageURL = pageLoadTask.GetURL();
					ui.UpdateAddressBar(page.pageURL);
					loadTaskTargetNode = page.GetRootNode();
					ui.SetStatusMessage("Parsing page content...", StatusBarNode::GeneralStatus);
					if (!parser.SetContentType(pageLoadTask.GetContentType()))
					{
						if (pageLoadTask.type == LoadTask::RemoteFile)
						{
							ShowDownloadDialogPage();
						}
						else
						{
							ShowErrorPage("Unsupported file format");
						}
					}
				}

				requestedNewPage = false;
			}

			size_t bytesRead = pageLoadTask.GetContent(loadBuffer, APP_LOAD_BUFFER_SIZE);
			if (bytesRead)
			{
				if (pageLoadTask.downloadFile)
				{
					fwrite(loadBuffer, 1, bytesRead, pageLoadTask.downloadFile);
				}
				else
				{
					if (pageLoadTask.debugDumpFile)
					{
						fwrite(loadBuffer, 1, bytesRead, pageLoadTask.debugDumpFile);
					}

					parser.Parse(loadBuffer, bytesRead);
				}
			}
		}
		else
		{
			if (requestedNewPage)
			{
				if (pageLoadTask.type == LoadTask::RemoteFile)
				{
					if (!pageLoadTask.request)
					{
						if (Platform::network->IsConnected())
						{
							ShowErrorPage("Failed to make network request");
						}
						else
						{
							ShowErrorPage("No network interface available");
						}
						requestedNewPage = false;
					}
					else if (pageLoadTask.request->GetStatus() == HTTPRequest::Error)
					{
						ShowErrorPage(pageLoadTask.request->GetStatusString());
						requestedNewPage = false;
					}
					else if (pageLoadTask.request->GetStatus() == HTTPRequest::UnsupportedHTTPS)
					{
						ShowNoHTTPSPage();
						requestedNewPage = false;
					}
				}
				else if (pageLoadTask.type == LoadTask::LocalFile)
				{
					ui.UpdateAddressBar(pageLoadTask.GetURL());
					ShowErrorPage("File not found");
					requestedNewPage = false;
				}
			}
			else if (pageLoadTask.downloadFile)
			{
				if (!pageLoadTask.IsBusy())
				{
					fclose(pageLoadTask.downloadFile);
					pageLoadTask.downloadFile = NULL;
					ShowDownloadEndedPage("Download complete!");
				}
			}
			else if (!parser.IsFinished())
			{
				parser.Finish();
			}
		}

		if (pageContentLoadTask.HasContent())
		{
			size_t bytesRead = pageContentLoadTask.GetContent(loadBuffer, APP_LOAD_BUFFER_SIZE);
			if (bytesRead)
			{
				bool stillProcessing = loadTaskTargetNode->Handler().ParseContent(loadTaskTargetNode, loadBuffer, bytesRead);
				if (!stillProcessing)
				{
					pageContentLoadTask.Stop();
				}
			}
		}
		else if(!pageContentLoadTask.IsBusy())
		{
			if (loadTaskTargetNode)
			{
				loadTaskTargetNode->Handler().FinishContent(loadTaskTargetNode, pageContentLoadTask);
				loadTaskTargetNode = page.ProcessNextLoadTask(loadTaskTargetNode, pageContentLoadTask);

				if (!loadTaskTargetNode && page.layout.IsFinished())
				{
					if (MemoryManager::pageAllocator.GetError())
					{
						page.GetApp().ui.SetStatusMessage("Out of memory when loading page", StatusBarNode::GeneralStatus);
					}
					else
					{
						page.GetApp().ui.ClearStatusMessage(StatusBarNode::GeneralStatus);
					}
				}
			}
		}
		//if (loadTask.type == LoadTask::RemoteFile && loadTask.request && loadTask.request->GetStatus() == HTTPRequest::Connecting)
		//	ui.SetStatusMessage(loadTask.request->GetStatusString());

		page.layout.Update();
		pageRenderer.Update();
		ui.Update();
	}
}

void LoadTask::Load(HTTPRequest::RequestType requestType, const char* targetURL, HTTPOptions* options)
{
	Stop();

	url = targetURL;

	// Check for protocol substring
	if (strstr(url.url, "http://") == url.url)
	{
		type = LoadTask::RemoteFile;
	}
	else if (strstr(url.url, "file://") == url.url)
	{
		type = LoadTask::LocalFile;
		fs = fopen(url.url + 7, "rb");
	}
	else if (strstr(url.url, "https://") == url.url)
	{
		type = LoadTask::RemoteFile;

		// Bit of a hack: try forcing http:// first
		strcpy(url.url + 4, url.url + 5);
	}
	else if (strstr(url.url, "://"))
	{
		// Will be an unsupported protocol
		type = LoadTask::RemoteFile;
	}
	else
	{
		// User did not include protocol, first check for local file
		type = LoadTask::LocalFile;
		fs = fopen(targetURL, "rb");

		if (fs)
		{
			// Local file exists, prepend with file:// protocol
			strcpy(url.url, "file://");
			strcpy(url.url + 7, targetURL);
		}
		else
		{
			// did this start with X:\ ?
			if (targetURL[0] >= 'A' && targetURL[0] <= 'z' && targetURL[1] == ':' && targetURL[2] == '\\')
			{
				type = LoadTask::LocalFile;
				fs = nullptr;
			}
			else
			{
				// Assume this should be http://
				type = LoadTask::RemoteFile;
				strcpy(url.url, "http://");
				strcpy(url.url + 7, targetURL);
			}
		}
	}

	url.CleanUp();

	if (type == LoadTask::RemoteFile)
	{
		request = Platform::network->CreateRequest();
		if (request)
		{
			request->Open(requestType, url.url, options);

			if (App::config.dumpPage && this == &App::Get().pageLoadTask)
			{
				debugDumpFile = fopen("dump.htm", "wb");
			}
		}
	}
}

void LoadTask::Stop()
{
	if (debugDumpFile)
	{
		fclose(debugDumpFile);
		debugDumpFile = NULL;
	}
	if (downloadFile)
	{
		fclose(downloadFile);
		downloadFile = NULL;
	}

	switch (type)
	{
	case LoadTask::LocalFile:
		if (fs)
		{
			fclose(fs);
			fs = nullptr;
		}
		break;
	case LoadTask::RemoteFile:
		if (request)
		{
			request->Stop();
			Platform::network->DestroyRequest(request);
			request = nullptr;
		}
		break;
	}
}

const char* LoadTask::GetURL()
{
	if (type == LoadTask::RemoteFile && request)
	{
		return request->GetURL();
	}
	return url.url;
}

bool LoadTask::IsBusy()
{
	bool isStillConnecting = type == LoadTask::RemoteFile && request && request->GetStatus() == HTTPRequest::Connecting;
	return isStillConnecting || HasContent();
}

bool LoadTask::HasContent()
{
	if (type == LoadTask::LocalFile)
	{
		return (fs && !feof(fs));
	}
	else if (type == LoadTask::RemoteFile)
	{
		return (request && request->GetStatus() == HTTPRequest::Downloading);
	}
	return false;
}

size_t LoadTask::GetContent(char* buffer, size_t count)
{
	if (type == LoadTask::LocalFile)
	{
		if (fs)
		{
			if (!feof(fs))
			{
				return fread(buffer, 1, count, fs);
			}
			fclose(fs);
		}
	}
	else if (type == LoadTask::RemoteFile)
	{
		if (request)
		{ 
			switch (request->GetStatus())
			{
			case HTTPRequest::Downloading:
				return request->ReadData(buffer, count);
			case HTTPRequest::Error:
			case HTTPRequest::Finished:
			case HTTPRequest::Stopped:
				Stop();
				break;
			}
		}
	}
	return 0;
}

const char* LoadTask::GetContentType()
{
	if (type == LoadTask::RemoteFile)
	{
		return request->GetContentType();
	}
	else
	{
		const char* extension = url.url + strlen(url.url);
		while (extension > url.url)
		{
			extension--;
			if (*extension == '.')
			{
				extension++;
				if (!stricmp(extension, "gif"))
				{
					return "image/gif";
				}
				else if (!stricmp(extension, "png"))
				{
					return "image/png";
				}
				else if (!stricmp(extension, "jpeg") || !stricmp(extension, "jpg"))
				{
					return "image/jpeg";
				}
				else if (!stricmp(extension, "htm") || !stricmp(extension, "html"))
				{
					return "text/html";
				}

				return "text/plain";
			}
		}

		return "text/html";
	}
}

void App::RequestNewPage(HTTPRequest::RequestType requestType, const char* url, HTTPOptions* options)
{
	if (!url || !*url)
		return;

	StopLoad();
	pageLoadTask.Load(requestType, url, options);
	requestedNewPage = true;
	loadTaskTargetNode = nullptr;
	//ui.UpdateAddressBar(loadTask.url);

	if (pageLoadTask.type == LoadTask::RemoteFile && pageLoadTask.request)
	{
		ui.SetStatusMessage("Connecting to server...", StatusBarNode::GeneralStatus);
	}
}

void App::OpenURL(HTTPRequest::RequestType requestType, const char* url, HTTPOptions* options)
{
	RequestNewPage(requestType, url, options);

	size_t urlStringLength = strlen(url) + 1;

	if (*pageHistoryPtr)
	{
		pageHistoryPtr += strlen(pageHistoryPtr) + 1;
	}

	// If not enough space in the buffer then move to previous space
	while (pageHistoryPtr + urlStringLength > pageHistoryBuffer + MAX_PAGE_HISTORY_BUFFER_SIZE)
	{
		size_t firstLength = strlen(pageHistoryBuffer);

		if (!firstLength)
		{
			// This shouldn't happen
			pageHistoryPtr = pageHistoryBuffer;
			break;
		}

		memmove(pageHistoryBuffer, pageHistoryBuffer + firstLength + 1, MAX_PAGE_HISTORY_BUFFER_SIZE - firstLength - 1);
		pageHistoryPtr -= firstLength + 1;
	}

	strcpy(pageHistoryPtr, url);
	memset(pageHistoryPtr + urlStringLength, 0, MAX_PAGE_HISTORY_BUFFER_SIZE - (pageHistoryPtr + urlStringLength - pageHistoryBuffer));
}

void App::StopLoad()
{
	pageLoadTask.Stop();
	pageContentLoadTask.Stop();
}

void App::ShowErrorPage(const char* message)
{
	StopLoad();
	ResetPage();

	page.SetTitle("Error");

	page.pageURL = pageLoadTask.GetURL();
	ui.UpdateAddressBar(page.pageURL);

	parser.Write("<html>");
	parser.Write("<h1>Error loading page</h1>");
	parser.Write("<hr>");
	parser.Write(message);
	parser.Write("</html>");
	parser.Finish();
}

static const char* frogFindURL = "http://frogfind.com/read.php?a=";
#define FROG_FIND_URL_LENGTH 31

void App::ShowNoHTTPSPage()
{
	ResetPage();

	page.SetTitle("HTTPS unsupported");
	page.pageURL = pageLoadTask.GetURL();
	ui.UpdateAddressBar(page.pageURL);

	StopLoad();

	page.pageURL = frogFindURL;
	strncpy(page.pageURL.url + FROG_FIND_URL_LENGTH, pageLoadTask.GetURL(), MAX_URL_LENGTH - FROG_FIND_URL_LENGTH);

	parser.Write("<html>");
	parser.Write("<h1>HTTPS unsupported</h1>");
	parser.Write("<hr>");
	parser.Write("Sorry this browser does not support HTTPS!<br>");
	parser.Write("<a href=\"");
	parser.Write(page.pageURL.url);
	parser.Write("\">Visit this site via FrogFind</a>");
	parser.Write("</html>");
	parser.Finish();
}

void App::PreviousPage()
{
	if (pageHistoryPtr > pageHistoryBuffer)
	{
		do
		{
			pageHistoryPtr--;
		} while (pageHistoryPtr > pageHistoryBuffer && pageHistoryPtr[-1]);

		RequestNewPage(HTTPRequest::Get, pageHistoryPtr);
	}
}

void App::NextPage()
{
	if (*pageHistoryPtr)
	{
		char* next = pageHistoryPtr + strlen(pageHistoryPtr) + 1;
		if (next < pageHistoryBuffer + MAX_PAGE_HISTORY_BUFFER_SIZE && *next)
		{
			pageHistoryPtr = next;
			RequestNewPage(HTTPRequest::Get, pageHistoryPtr);
		}
	}
}

void App::ReloadPage()
{
	if (*pageHistoryPtr)
	{
		RequestNewPage(HTTPRequest::Get, pageHistoryPtr);
	}
}

void App::LoadImageNodeContent(Node* node)
{
	loadTaskTargetNode = node;
	node->Handler().LoadContent(node, pageContentLoadTask);
}

void VideoDriver::InvertVideoOutput()
{
	if (drawSurface->format == DrawSurface::Format_1BPP)
	{
		App::config.invertScreen = !App::config.invertScreen;

		DrawContext context(drawSurface, 0, 0, screenWidth, screenHeight);
		Platform::input->HideMouse();
		context.surface->InvertRect(context, 0, 0, screenWidth, screenHeight);
		Platform::input->ShowMouse();
	}
}

void App::ShowDownloadProgressPage(const char* savePath)
{
	ResetPage();
	parser.Write("<html><body><center>");
	parser.Write("<h1>Downloading</h1>");
	parser.Write("<hr>");
	parser.Write(page.pageURL.url);
	parser.Write("<br> to ");
	parser.Write(savePath);
	parser.Write("<hr>");
	parser.Write("<form action=\"cancel://\">");
	parser.Write("<input type=\"button\" value=\"Cancel\"/>");
	parser.Write("</form>");
	parser.Write("</center></body></html>");

	parser.Finish();
}

void App::ShowDownloadEndedPage(const char* message)
{
	ResetPage();
	parser.Write("<html><body><center><h1>");
	parser.Write(message);
	parser.Write("</h1></center></body></html>");

	parser.Finish();
}

void App::ShowDownloadDialogPage()
{
	char temp[32];
	char filename[14];

	parser.Write("<html><body><center>");
	parser.Write("<h1>Do you want to download this file?</h1>");
	parser.Write("<hr>");
	parser.Write(pageLoadTask.url.url);
	parser.Write("<br><b>Content type: ");
	parser.Write(pageLoadTask.GetContentType());

	long contentSize = pageLoadTask.request->GetContentSize();
	if (contentSize != 0)
	{
		parser.Write("<br>Size: ");
			
		if (contentSize < 1000)
		{
			snprintf(temp, 32, "%d bytes", contentSize);
		}
		else if (contentSize < 1000000l)
		{
			snprintf(temp, 32, "%d KB", contentSize / 1000);
		}
		else
		{
			snprintf(temp, 32, "%d MB", contentSize / 1000000l);
		}
		parser.Write(temp);
	}

	const char* srcFilename = pageLoadTask.url.url;
	const char* ptr;

	while (ptr = strchr(srcFilename, '/'))
	{
		srcFilename = ptr + 1;
	}

	int filenameLength = 0;

	for (int n = 0; n < 8; n++)
	{
		if (srcFilename[n] == '\0' || srcFilename[n] == '.')
		{
			break;
		}
		filename[n] = srcFilename[n];
		filenameLength++;
	}

	if (ptr = strchr(srcFilename, '.'))
	{
		for (int n = 0; n < 4; n++)
		{
			filename[filenameLength++] = ptr[n];
		}
	}

	filename[filenameLength] = '\0';

	parser.Write("</b><hr>");
	parser.Write("<form action=\"download://\">");
	parser.Write("<input name=\"path\" type=\"text\" width=\"75%\" value=\"");
	parser.Write(getcwd(NULL, 0));
#ifdef _WIN32
	parser.Write("\\");
#endif
	parser.Write(filename);
	parser.Write("\"/><br>");
	parser.Write("<br>");
	parser.Write("<input type=\"button\" value=\"Download\"/>");
	parser.Write("</form>");
	parser.Write("</center></body></html>");

	parser.Finish();
}

void App::BeginFileDownload(const char* savePath)
{
	FILE* downloadFile = fopen(savePath, "wb");
	if (downloadFile)
	{
		ShowDownloadProgressPage(savePath);
		pageLoadTask.Load(HTTPRequest::Get, pageLoadTask.url.url);
		requestedNewPage = true;
		pageLoadTask.downloadFile = downloadFile;
		ui.SetStatusMessage("Connecting to server...", StatusBarNode::GeneralStatus);
	}
}

void App::CancelFileDownload()
{
	if (pageLoadTask.downloadFile)
	{
		StopLoad();
		ShowDownloadEndedPage("Download cancelled");
	}
}
